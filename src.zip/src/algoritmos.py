import dash
from dash import dcc, html, Input, Output, State
import dash_cytoscape as cyto
import dash_bootstrap_components as dbc
import networkx as nx
import base64
import os
import io
import base64


def executar_bfs(G, selected_nodes, ponderado, orientado, gerar_elementos_cytoscape):
    # Gera os elementos inicialmente para garantir que sempre haverá um valor de retorno
    elements = gerar_elementos_cytoscape(G)

    # Verifica se o grafo está vazio
    if G.number_of_nodes() == 0:
        return elements, html.P("Nenhum grafo carregado.")  # Retorna os elementos com a mensagem de erro

    # Verifica se há exatamente um nó selecionado
    if selected_nodes is None or len(selected_nodes) != 1:
        return elements, html.P("Selecione exatamente um nó para iniciar a busca BFS.")

    try:
        # Inicia a BFS a partir do nó selecionado
        start_node = selected_nodes[0]['id']
        bfs_result = list(nx.bfs_edges(G, source=start_node))
        bfs_nodes = set([start_node] + [node for edge in bfs_result for node in edge])  # Coleta todos os nós visitados

        # Gera novamente os elementos do grafo
        elements = gerar_elementos_cytoscape(G)

        # Reseta as cores das arestas e nós para o padrão
        for element in elements:
            if 'data' in element:
                if 'source' in element['data'] and 'target' in element['data']:
                    element['style'] = element.get('style', {})
                    element['style']['line-color'] = '#252525'  # Cor padrão das arestas
                elif 'id' in element['data']:  # Para os nós
                    element['style'] = element.get('style', {})
                    element['style']['background-color'] = '#FFFFFF'  # Cor padrão dos nós

        # Destaque o caminho percorrido e os nós visitados na BFS
        for u, v in bfs_result:
            for edge in elements:
                if 'data' in edge and 'source' in edge['data'] and 'target' in edge['data']:
                    # Verifica em ambas as direções para grafos não orientados
                    if (edge['data']['source'] == u and edge['data']['target'] == v) or (edge['data']['source'] == v and edge['data']['target'] == u):
                        edge['style'] = edge.get('style', {})
                        edge['style']['line-color'] = 'red'  # Destaca o caminho da BFS

        # Destaque os nós visitados
        for node_id in bfs_nodes:
            for node in elements:
                if 'data' in node and 'id' in node['data']:
                    if node['data']['id'] == node_id:
                        node['style'] = node.get('style', {})
                        node['style']['background-color'] = 'yellow'  # Destaca os nós visitados

        # Cria a lista de adjacência formatada
        adjacency_list = [
            html.P(
                children=[
                    html.B(sorted(node)),  # Vértice em negrito
                    " -> ",
                    ', '.join(map(str, sorted(neighbors)))  # Ordena os vizinhos
                ],
                style={'margin': '0', 'padding': '0'}  # Remove margens e espaçamentos
            ) for node, neighbors in nx.to_dict_of_lists(G).items()
        ]

        # Informações adicionais sobre o grafo e o resultado da BFS
        info = [
            html.P(f"Número de Vértices: ", style={'display': 'inline'}),
            html.B(f"{len(G.nodes)}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Número de Arestas: ", style={'display': 'inline'}),
            html.B(f"{len(G.edges)}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Ponderado: ", style={'display': 'inline'}),
            html.B(f"{'Sim' if ponderado else 'Não'}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Orientado: ", style={'display': 'inline'}),
            html.B(f"{'Sim' if orientado else 'Não'}", style={'display': 'inline'}),
            html.Br(),
            html.Br(),
            html.P(f"Lista de Adjacência: "),
            *adjacency_list,  # Exibindo a lista de adjacência formatada
            html.Br(),
            html.P(f"Resultado BFS a partir do nó: ", style={'display': 'inline'}),
            html.B(f"'{start_node}': {bfs_result}", style={'display': 'inline'}),
        ]

        return elements, info

    except nx.NetworkXError as e:
        # Tratamento de erro da biblioteca NetworkX (caso o nó inicial não seja válido ou outro erro)
        return elements, html.P(f"Erro ao executar BFS: {str(e)}")

    # Caso algum outro erro ocorra
    return elements, html.P("Erro desconhecido ao executar a busca BFS.")

def executar_dfs(G, selected_nodes, ponderado, orientado, gerar_elementos_cytoscape):
    # Gera os elementos inicialmente para garantir que sempre haverá um valor de retorno
    elements = gerar_elementos_cytoscape(G)

    # Verifica se o grafo está vazio
    if G.number_of_nodes() == 0:
        return elements, html.P("Nenhum grafo carregado.")  # Retorna os elementos com a mensagem de erro

    # Verifica se há exatamente um nó selecionado
    if selected_nodes is None or len(selected_nodes) != 1:
        return elements, html.P("Selecione exatamente um nó para iniciar a busca DFS.")

    try:
        # Inicia a DFS a partir do nó selecionado
        start_node = selected_nodes[0]['id']
        visited = set()
        dfs_edges = []  # Arestas do caminho DFS
        return_edges = []  # Arestas de retorno (de volta para nós visitados)

        # Função auxiliar para realizar a DFS
        def dfs(v):
            visited.add(v)
            for u in G.neighbors(v):
                if u not in visited:
                    dfs_edges.append((v, u))  # Aresta de caminho DFS
                    dfs(u)
                elif (v, u) not in dfs_edges and (u, v) not in dfs_edges:
                    return_edges.append((v, u))  # Aresta de retorno

        # Inicia a DFS do nó inicial
        dfs(start_node)

        # Gera novamente os elementos do grafo
        elements = gerar_elementos_cytoscape(G)

        # Reseta as cores das arestas e nós para o padrão
        for element in elements:
            if 'data' in element:
                if 'source' in element['data'] and 'target' in element['data']:
                    element['style'] = element.get('style', {})
                    element['style']['line-color'] = '#252525'  # Cor padrão das arestas
                elif 'id' in element['data']:  # Para os nós
                    element['style'] = element.get('style', {})
                    element['style']['background-color'] = '#FFFFFF'  # Cor padrão dos nós

        # Destaque o caminho DFS em vermelho
        for u, v in dfs_edges:
            for edge in elements:
                if 'data' in edge and 'source' in edge['data'] and 'target' in edge['data']:
                    # Verifica em ambas as direções para grafos não orientados
                    if (edge['data']['source'] == u and edge['data']['target'] == v) or (not orientado and edge['data']['source'] == v and edge['data']['target'] == u):
                        edge['style']['line-color'] = 'red'  # Cor vermelha para arestas do caminho DFS

        # Destaque as arestas de retorno em azul
        for u, v in return_edges:
            for edge in elements:
                if 'data' in edge and 'source' in edge['data'] and 'target' in edge['data']:
                    # Verifica em ambas as direções para grafos não orientados
                    if (edge['data']['source'] == u and edge['data']['target'] == v) or (not orientado and edge['data']['source'] == v and edge['data']['target'] == u):
                        edge['style']['line-color'] = 'blue'  # Cor azul para arestas de retorno

        # Cria a lista de adjacência formatada
        adjacency_list = [
            html.P(
                children=[
                    html.B(sorted(node)),  # Vértice em negrito
                    " -> ",
                    ', '.join(map(str, sorted(neighbors)))  # Ordena os vizinhos
                ],
                style={'margin': '0', 'padding': '0'}  # Remove margens e espaçamentos
            ) for node, neighbors in nx.to_dict_of_lists(G).items()
        ]

        # Informações adicionais sobre o grafo e o resultado da DFS
        info = [
            html.P(f"Número de Vértices: ", style={'display': 'inline'}),
            html.B(f"{len(G.nodes)}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Número de Arestas: ", style={'display': 'inline'}),
            html.B(f"{len(G.edges)}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Ponderado: ", style={'display': 'inline'}),
            html.B(f"{'Sim' if ponderado else 'Não'}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Orientado: ", style={'display': 'inline'}),
            html.B(f"{'Sim' if orientado else 'Não'}", style={'display': 'inline'}),
            html.Br(),
            html.Br(),
            html.P(f"Lista de Adjacência: "),
            *adjacency_list,  # Exibindo a lista de adjacência formatada
            html.Br(),
            html.P(f"Resultado DFS a partir do nó: ", style={'display': 'inline'}),
            html.B(f"'{start_node}': {dfs_edges}", style={'display': 'inline'}),
        ]

        return elements, info

    except nx.NetworkXError as e:
        # Tratamento de erro da biblioteca NetworkX (caso o nó inicial não seja válido ou outro erro)
        return elements, html.P(f"Erro ao executar DFS: {str(e)}")

    # Caso algum outro erro ocorra
    return elements, html.P("Erro desconhecido ao executar a busca DFS.")

def executar_mst(G, gerar_elementos_cytoscape, ponderado, orientado):
    # Gera os elementos inicialmente para garantir que sempre haverá um valor de retorno
    elements = gerar_elementos_cytoscape(G)

    # Verifica se o grafo está vazio
    if G.number_of_nodes() == 0:
        return elements, html.P("Nenhum grafo carregado.")  # Retorna os elementos com a mensagem de erro

    try:
        # Certifica-se de que todas as arestas tenham um peso numérico (default 1.0 se não houver)
        for u, v, data in G.edges(data=True):
            if 'weight' not in data or not isinstance(data['weight'], (int, float)):
                data['weight'] = 1.0  # Define um peso padrão se não houver ou for inválido

        # Calcula a Árvore Geradora Mínima (MST) com o algoritmo de Kruskal
        mst = nx.minimum_spanning_tree(G, weight='weight', algorithm='kruskal')

        # Gera novamente os elementos do grafo
        elements = gerar_elementos_cytoscape(G)

        # Pintar as arestas da MST de verde
        mst_edges = set(mst.edges())  # Conjunto de arestas da MST
        for edge in elements:
            if 'data' in edge and 'source' in edge['data'] and 'target' in edge['data']:
                source = edge['data']['source']
                target = edge['data']['target']
                # Verifica se a aresta faz parte da MST (considerando grafos não direcionados)
                if (source, target) in mst_edges or (target, source) in mst_edges:
                    edge['style'] = edge.get('style', {})
                    edge['style']['line-color'] = 'green'  # Destaca as arestas da MST em verde

        # Organizar as arestas da MST em um grid flexível
        mst_result = []
        for i, (u, v, data) in enumerate(mst.edges(data=True)):
            # Adiciona as arestas com layout mais compacto
            mst_result.append(html.Span(f"Aresta: ({u}, {v}), PESO: {data['weight']}", style={'margin': '2px', 'padding': '0', 'display': 'inline-block', 'width': '150px'}))

            # Quebra de linha após cada 6 elementos
            if (i + 1) % 6 == 0:
                mst_result.append(html.Br())

        # Gerar a lista de adjacência do grafo original para exibição
        adjacency_list = [
            html.P(
                children=[
                    html.B(node),  # Vértice em negrito
                    " -> ",
                    ', '.join(map(str, sorted(neighbors)))  # Ordena os vizinhos em ordem crescente
                ],
                style={'margin': '0', 'padding': '0'}  # Remove margens e espaçamentos
            ) for node, neighbors in nx.to_dict_of_lists(G).items()
        ]

        # Informações adicionais sobre o grafo e o resultado da MST
        info = [
            html.P(f"Número de Vértices: ", style={'display': 'inline'}),
            html.B(f"{len(G.nodes)}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Número de Arestas: ", style={'display': 'inline'}),
            html.B(f"{len(G.edges)}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Ponderado: ", style={'display': 'inline'}),
            html.B(f"{'Sim' if ponderado else 'Não'}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Orientado: ", style={'display': 'inline'}),
            html.B(f"{'Sim' if orientado else 'Não'}", style={'display': 'inline'}),
            html.Br(),
            html.Br(),
            html.P(f"Lista de Adjacência: "),  # Exibe a lista de adjacência normal do grafo
            *adjacency_list,
            html.Br(),
            html.P(f"Resultado da Árvore Geradora Mínima (MST): "),
            html.Div(mst_result, style={'display': 'flex', 'flex-wrap': 'wrap', 'max-width': '600px'})  # Limita a largura máxima para 600px
        ]

        # Retorna os elementos atualizados e as informações
        return elements, info

    except Exception as e:
        # Tratamento genérico de erros
        return elements, html.P(f"Erro ao calcular a MST: {str(e)}")
