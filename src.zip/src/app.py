import dash
from dash import dcc, html, Input, Output, State
import dash_cytoscape as cyto
import dash_bootstrap_components as dbc
import networkx as nx
import base64
import os
import io
import base64
from algoritmos import executar_bfs, executar_dfs, executar_mst

# Configuração da aplicação
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

G = nx.Graph()
orientado = False
ponderado = False
arestas_originais = []

history = []  # Lista global para armazenar as ações realizadas


app.layout = html.Div([
    # Fundo principal
    html.Div(
        style={
            'background-color': '#f8f9fa',
            'min-height': '100vh',
            'display': 'flex',
            'flex-direction': 'column',
            'align-items': 'center',
            'justify-content': 'flex-start',
        },
        children=[

            # Cabeçalho
            html.Header(
                children=[
                    html.Div(
                        children=[
                            html.Img(src='/assets/diagram-3-fill.svg', alt='Ícone de Grafo', style={'height': '60px', 'margin-right': '10px'}),
                            html.H1("REPRESENTAÇÃO DE GRAFOS", style={'margin': '0', 'font-size': '2rem'})
                        ],
                        style={
                            'display': 'flex',
                            'align-items': 'center',
                            'justify-content': 'center',
                        },
                    )
                ],
                style={
                    'display': 'flex',
                    'align-items': 'center',
                    'justify-content': 'center',
                    'background-color': '#ffffff',
                    'width': '100%',
                    'box-shadow': '0 4px 8px rgba(0, 0, 0, 0.1)',
                    'margin-bottom': '30px',
                    'padding': '15px'
                }
            ),

            # Segunda Div para Botões e Entrada de Dados
            html.Div(
                style={
                    'display': 'flex',
                    'flex-direction': 'column',
                    'width': '90%',
                    'border-radius': '10px',
                    'margin-bottom': '30px'
                },
                children=[
                    # Grupo de botões centralizados
                    dbc.ButtonGroup(
                        [
                            dbc.DropdownMenu(
                                label=[html.Img(src='/assets/gear.svg', style={'height': '20px', 'margin-right': '5px'}), "Grafo"],
                                children=[
                                    dcc.Upload(
                                        id='upload-data',
                                        children=dbc.DropdownMenuItem([
                                            html.Img(src='/assets/upload.svg', style={'height': '20px', 'margin-right': '5px'}),
                                            "Carregar Grafo"
                                        ]),
                                        multiple=False,
                                        style={
                                            'width': '100%',
                                            'height': '60px',
                                            'lineHeight': '60px',
                                            'borderWidth': '1px',
                                            'borderStyle': 'dashed',
                                            'borderRadius': '1px',
                                            'textAlign': 'center',
                                        },
                                    ),
                                    html.Div(id='output-data-upload'),
                                    dbc.DropdownMenuItem([html.Img(src='/assets/save.svg', style={'height': '20px', 'margin-right': '5px'}), "Baixar Grafo"], id="salvar-grafo", n_clicks=0),
                                    dcc.Download(id="download-text"),
                                    dbc.DropdownMenuItem([html.Img(src='/assets/arrow-down-up.svg', style={'height': '20px', 'margin-right': '5px'}), "Orientado"], id="transformar_orientado", n_clicks=0),
                                    dbc.DropdownMenuItem([html.Img(src='/assets/arrows.svg', style={'height': '20px', 'margin-right': '5px'}), "Não Orientado"], id="transformar_nao_orientado", n_clicks=0),
                                    dbc.DropdownMenuItem([html.Img(src='/assets/1-circle-fill.svg', style={'height': '20px', 'margin-right': '5px'}), "Ponderado"], id="transformar_ponderado", n_clicks=0),
                                    dbc.DropdownMenuItem([html.Img(src='/assets/0-circle-fill.svg', style={'height': '20px', 'margin-right': '5px'}), "Não Ponderado"], id="transformar_nao_ponderado", n_clicks=0)
                                ],
                                toggle_style={'margin': '0 10px', 'border-radius': '6px'}
                            ),
                            dbc.DropdownMenu(
                                label=[html.Img(src='/assets/gear.svg', style={'height': '20px', 'margin-right': '5px'}), "Algoritmos"],
                                children=[
                                    dbc.DropdownMenuItem([html.Img(src='/assets/gear-wide-connected.svg', style={'height': '20px', 'margin-right': '5px'}), "BFS"], id="BFS", n_clicks=0),
                                    dbc.DropdownMenuItem([html.Img(src='/assets/gear-wide-connected.svg', style={'height': '20px', 'margin-right': '5px'}), "DFS"], id="DFS", n_clicks=0),
                                    dbc.DropdownMenuItem([html.Img(src='/assets/gear-wide-connected.svg', style={'height': '20px', 'margin-right': '5px'}), "KRUSKAL"], id="MST", n_clicks=0),
                                ],
                                toggle_style={'margin': '0 10px', 'border-radius': '6px'}
                            ),
                            dbc.Button([html.Img(src='/assets/plus-lg.svg', style={'height': '20px', 'margin-right': '5px'}), "Adicionar Vértice"], color="success", style={'margin': '0 10px', 'border-radius': '6px'}, id='adicionar_vertice', n_clicks=0),
                            dbc.Input(id='entrada_vertice', type='value', placeholder='Nome do Vértice', style={'margin-right': '5px', 'width': '145px', 'border-radius': '6px'}),
                            dbc.Button([html.Img(src='/assets/dash-lg.svg', style={'height': '20px', 'margin-right': '5px'}), "Remover Vértice"], color="danger", style={'margin': '0 10px', 'border-radius': '6px'}, id='remover_vertice', n_clicks=0),
                            dbc.Button([html.Img(src='/assets/arrows-vertical.svg', style={'height': '20px', 'margin-right': '5px'}), "Adicionar Aresta"], color="success", style={'margin': '0 10px', 'border-radius': '6px'}, id='adicionar_aresta', n_clicks=0),
                            dbc.Button([html.Img(src='/assets/arrows-vertical.svg', style={'height': '20px', 'margin-right': '5px'}), "Remover Aresta"], color="danger", style={'margin': '0 10px', 'border-radius': '6px'}, id='remover_aresta', n_clicks=0)
                            
                        ],
                        style={'display': 'flex', 'justify-content': 'center', 'margin-bottom': '20px'}
                    ),

 
                    dbc.ButtonGroup(
                        [
                            dbc.Button([html.Img(src='/assets/lightning-charge-fill.svg', style={'height': '20px', 'margin-right': '5px'}), "Atualizar"], color="success", style={'margin': '0 10px', 'border-radius': '6px'}, id='Atualizar', n_clicks=0),
                            dbc.Button([html.Img(src='/assets/lightning-charge-fill.svg', style={'height': '20px', 'margin-right': '5px'}), "Adicionar Peso"], color="success", style={'margin': '0 10px', 'border-radius': '6px'}, id='adicionar_peso', n_clicks=0),
                            dbc.Input(id='entrada_peso', type='value', placeholder='Peso da Aresta', style={'margin-right': '5px', 'width': '200px'}),
                        ],
                        style={'display': 'flex', 'justify-content': 'center'}
                    )
                ]
            ),

            # Div para visualização do Cytoscape
           html.Div([
                html.Div(id="grafo-info", style={
                    'position': 'absolute', 'top': '10px', 'left': '10px', 'z-index': '10'
                }),  # Informações do grafo no canto superior esquerdo
                cyto.Cytoscape(
                    id='visualizacao_grafo',
                    layout={'name': 'circle', 'animate': True},
                    style={'width': '100%', 'height': '600px'},
                    elements=[],
                    stylesheet=[
                        {'selector': 'node', 'style': {'label': 'data(label)', 'text-valign': 'center', 'text-halign': 'center'}},
                        {'selector': 'edge', 'style': {'curve-style': 'bezier'}}
                    ],
                    minZoom=1.0,
                    maxZoom=4.0
                ),
                html.Div(
                    dbc.Button('Layout', id='layout-button', n_clicks=0, className='ml-auto', color="info", style={'position': 'absolute', 'top': 10, 'right': 10})
                ),
            ], style={'width': '90%', 'height': '600px', 'border': '1px solid black', 'position': 'relative'})
        ]
    )
])


def salvar_grafo_txt(grafo, orientado=False):
    """Função para salvar o grafo no formato .txt"""
    linhas = []
    for u, v, data in grafo.edges(data=True):
        if orientado:
            linhas.append(f"{u}, {v}")
        else:
            if (v, u) not in grafo.edges():  # Evitar duplicatas em grafos não orientados
                linhas.append(f"{u}, {v}")
    
    conteudo = "\n".join(linhas)
    return conteudo  # Retorna o conteúdo como uma string

    
# def gerar_lista_adjacencia_txt(G):
#     output = io.StringIO()
#     for node in G.nodes:
#         vizinhos = G[node]
#         for vizinho, dados in vizinhos.items():
#             peso = dados.get('weight')  # Pega o peso da aresta, se existir
#             output.write(f"{node}, {vizinho}, {peso}\n")
#     return output.getvalue()


def gerar_elementos_cytoscape(G):
    elements = []

    # Adicionar os nós
    for node in G.nodes():
        elements.append({
            'selector': f'node[id="{node}"]',
            'data': {'id': str(node), 'label': str(node)},
            'classes': 'node',
            'style': {
                'border-width': '1.0px',
                'border-color': '#252525'
            }
        })

    # Verificar se o grafo tem pesos nas arestas
    grafo_tem_peso = any('weight' in data for _, _, data in G.edges(data=True))

    # Adicionar as arestas
    for edge in G.edges(data=True):
        source, target, data = edge
        label = ''

        # Se o grafo for ponderado, exibir o peso
        if ponderado and 'weight' in data:
            label = str(data['weight'])

        elements.append({
            'selector': f'edge[source="{source}"][target="{target}"]',
            'data': {
                'source': str(source),
                'target': str(target),
                'label': label  # Apenas exibir se o grafo for ponderado
            },
            'classes': 'edge',
            'style': {
                'width': '2.8px',
                'target-arrow-color': '#252525',
                'target-arrow-shape': 'triangle' if nx.is_directed(G) else 'none',
                'arrow-scale': 1.3,
                'label': label,  # Apenas exibir se o grafo for ponderado
                'text-background-color': '#ffffff' if label else '',
                'text-background-opacity': 0.5 if label else 0,
                'text-background-shape': 'round-rectangle' if label else 'none',
            }
        })

    return elements


def carregar_grafo_txt(filename):
    global arestas_originais  # Referencia a variável global
    G = nx.Graph()  # Inicializa um grafo não direcionado (default)
    ponderado = False
    orientado = False
    
    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()
            if not line:
                continue
            parts = line.split(',')
            if len(parts) == 2:
                u, v = parts
                G.add_edge(u.strip(), v.strip())
                arestas_originais.append((u.strip(), v.strip()))  # Armazena a aresta original
            elif len(parts) == 3:
                u, v, peso = parts
                G.add_edge(u.strip(), v.strip(), weight=float(peso.strip()))
                arestas_originais.append((u.strip(), v.strip(), float(peso.strip())))  # Armazena a aresta original com peso
                ponderado = True

    return G, ponderado, orientado


def desfazer_acao(grafo):
    if history:
        # Pega a última ação
        acao = history.pop()

        # Desfaz a ação
        if acao[0] == 'adicionar_vertice':
            remover_vertice(G, acao[1])
        elif acao[0] == 'remover_vertice':
            G.add_node(acao[1])
        elif acao[0] == 'adicionar_aresta':
            remover_aresta(G, acao[1], acao[2])
        elif acao[0] == 'remover_aresta':
            G.add_edge(acao[1], acao[2])



def remover_vertice(G, vertice):

    if G.has_node(vertice):
        G.remove_node(vertice)
    else:
        print(f"{vertice} não foi encontrado no grafo, verifique se ele existe.")

def remover_aresta(G, source, target):

    if G.has_edge(source, target):
        G.remove_edge(source, target)
    else:
        print(f"Aresta de {source} para {target} não encontrada no grafo, verifique se ela existe.")

@app.callback(
    [Output('visualizacao_grafo', 'elements'),
     Output('grafo-info', 'children')],
    [Input('upload-data', 'contents'),
    #  Input('salvar-grafo', 'n_clicks'),
     Input('adicionar_vertice', 'n_clicks'),
     Input('adicionar_aresta', 'n_clicks'),
     Input('remover_vertice', 'n_clicks'),
     Input('remover_aresta', 'n_clicks'),
     Input('transformar_orientado', 'n_clicks'),
     Input('transformar_nao_orientado', 'n_clicks'),
     Input('adicionar_peso', 'n_clicks'),
     Input('transformar_ponderado', 'n_clicks'),
     Input('transformar_nao_ponderado', 'n_clicks'),
     Input('BFS', 'n_clicks'),
     Input('DFS', 'n_clicks'),
     Input('MST', 'n_clicks'),
     Input('Atualizar', 'n_clicks'),
     Input('visualizacao_grafo', 'selectedNodeData'),
     Input('visualizacao_grafo', 'selectedEdgeData')],
    [State('upload-data', 'filename'),
     State('entrada_vertice', 'value'),
     State('entrada_peso', 'value'),
     State('visualizacao_grafo', 'elements')]
)


def update_graph(contents, add_node_clicks, add_edge_clicks, remove_node_clicks, remove_edge_clicks, refresh_button,
                to_directed_clicks, to_undirected_clicks, add_weight_clicks, bfs_clicks, btn_make_weighted_clicks, 
                btn_make_unweighted_clicks, dfs_clicks, n_clicks_mst, selected_nodes, selected_edges, filename, add_node, add_edge_weight, elements):
    
    global G, ponderado, orientado
    ctx = dash.callback_context
    
    if not ctx.triggered:
        return gerar_elementos_cytoscape(G), [html.P("Nenhum grafo carregado.")]
    
    button_id = ctx.triggered[0]['prop_id'].split('.')[0]

    try:
        if button_id == 'upload-data' and contents is not None:
            G.clear()
            arestas_originais.clear()
            history.clear()

            content_type, content_string = contents.split(',')
            decoded = base64.b64decode(content_string).decode('utf-8')
            
            temp_filename = 'temp_graph.txt'
            with open(temp_filename, 'w') as temp_file:
                temp_file.write(decoded)
            
            G, ponderado, orientado = carregar_grafo_txt(temp_filename)
            os.remove(temp_filename)
            elements = gerar_elementos_cytoscape(G)

        # elif button_id == 'salvar-grafo':
        #     # Transformar os elementos do grafo para o formato NetworkX
        #     G = nx.Graph()
        #     for edge in elements:
        #         if 'source' in edge['data'] and 'target' in edge['data']:
        #             G.add_edge(edge['data']['source'], edge['data']['target'])

        #     # Verificar se o grafo é orientado ou não, e salvar como txt
        #     return elements, salvar_grafo_txt(G, G.is_directed())
        
        elif button_id == 'adicionar_vertice':

            # Verifica se o input não está vazio e se o vértice não existe
            if add_node and add_node not in G.nodes():
                G.add_node(add_node)
                history.append(('adicionar_vertice', add_node))
                elements = gerar_elementos_cytoscape(G)
            else:
                # Retorna uma mensagem de erro se o input estiver vazio ou o vértice já existir
                if not add_node:
                    return elements, html.P("Por favor, insira um nome para o vértice.")
                return elements, html.P(f"Erro: Vértice '{add_node}' já existe ou o campo está vazio.")


        elif button_id == 'remover_vertice':
            if G.number_of_nodes() == 0:
                return elements, html.P("Nenhum grafo carregado.")

            if selected_nodes:
                for node_data in selected_nodes:
                    # Salva as arestas conectadas ao vértice antes de removê-lo
                    arestas_conectadas = list(G.edges(node_data['id']))
                    for u, v in arestas_conectadas:
                        for aresta in arestas_originais:
                            if (aresta[0] == u and aresta[1] == v) or (aresta[0] == v and aresta[1] == u):
                                arestas_originais.remove(aresta)
                    remover_vertice(G, node_data['id'])
                    history.append(('remover_vertice', node_data['id']))
                elements = gerar_elementos_cytoscape(G)
            else:
                return elements, html.P("Nenhum vértice selecionado.")

        elif button_id == 'adicionar_aresta':
            if G.number_of_nodes() == 0:
                return elements, html.P("Nenhum grafo carregado.")
        
            if len(selected_nodes) == 1:
                # Auto-loop: caso o mesmo nó seja clicado duas vezes ou apenas um nó seja selecionado
                source = selected_nodes[0]['id']
                target = source  # Auto-loop (source == target)
        
                if not G.has_edge(source, target):
                    if ponderado:
                        G.add_edge(source, target, weight=1.0)
                        history.append(('adicionar_aresta', source, target, 1.0))
                        arestas_originais.append((source, target, 1.0))  # Salva a aresta original
                    else:
                        G.add_edge(source, target)
                        history.append(('adicionar_aresta', source, target, None))
                        arestas_originais.append((source, target, {}))  # Salva a aresta original
        
                elements = gerar_elementos_cytoscape(G)
        
            elif len(selected_nodes) >= 2:
                error_messages = []
                for i in range(len(selected_nodes) - 1):
                    source = selected_nodes[i]['id']
                    target = selected_nodes[i + 1]['id']
                    if not G.has_edge(source, target):
                        try:
                            if ponderado:
                                G.add_edge(source, target, weight=1.0)
                                history.append(('adicionar_aresta', source, target, 1.0))
                                arestas_originais.append((source, target, 1.0))
                            else:
                                G.add_edge(source, target)
                                history.append(('adicionar_aresta', source, target, 1.0))
                                arestas_originais.append((source, target, 1.0))
                        except nx.NetworkXError as e:
                            error_messages.append(str(e))
        
                elements = gerar_elementos_cytoscape(G)
                if error_messages:
                    return elements, html.P('\n'.join(error_messages))
            else:
                return elements, html.P("Selecione um (auto-loop) ou mais vértices para adicionar uma aresta.")


        elif button_id == 'remover_aresta':
            if G.number_of_nodes() == 0:
                return elements, html.P("Nenhum grafo carregado.")

            if selected_edges:
                for edge_data in selected_edges:
                    arestas_originais.append((edge_data['source'], edge_data['target'], G[edge_data['source']][edge_data['target']]))  # Salva a aresta original
                    remover_aresta(G, edge_data['source'], edge_data['target'])
                    history.append(('remover_aresta', edge_data['source'], edge_data['target']))
                elements = gerar_elementos_cytoscape(G)
            else:
                return elements, html.P("Nenhuma aresta selecionada.")


        elif button_id == 'adicionar_peso':
            if G.number_of_nodes() == 0:
                return elements, html.P("Nenhum grafo carregado.") 

            if selected_edges and add_edge_weight is not None:
                weight = float(add_edge_weight)
                if not ponderado:
                    ponderado = True
                    for edge in G.edges():
                        G[edge[0]][edge[1]]['weight'] = 1.0
                        arestas_originais.append((edge[0], edge[1], 1.0))  # Salva a aresta original
                for edge_data in selected_edges:
                    G[edge_data['source']][edge_data['target']]['weight'] = weight
                    arestas_originais.append((edge_data['source'], edge_data['target'], weight))  # Salva a aresta original
                elements = gerar_elementos_cytoscape(G)
            else:
                if not selected_edges:
                    return elements, html.P("Nenhuma aresta selecionada.")
                if add_edge_weight is None:
                    return elements, html.P("Por favor, insira um peso para a aresta.")

            return elements, html.P("Nenhuma aresta selecionada ou peso não fornecido.")

        elif button_id == 'BFS':
            elements, info = executar_bfs(G, selected_nodes, ponderado, orientado, gerar_elementos_cytoscape)
            return elements, info

        elif button_id == 'DFS':
            elements, info = executar_dfs(G, selected_nodes, ponderado, orientado, gerar_elementos_cytoscape)
            return elements, info

        elif button_id == 'MST':
            elements, info = executar_mst(G, gerar_elementos_cytoscape, ponderado, orientado)
            return elements, info


        elif button_id == 'transformar_orientado':
            if G.number_of_nodes() == 0:
                return elements, html.P("Nenhum grafo carregado.")
        
            if len(G.edges) <= 0:
                return elements, html.P("Número de arestas insuficiente para converter.")
        
            if G.is_directed():
                return elements, "O grafo já é orientado."
        
            # Cria um grafo orientado a partir das arestas originais
            G_dir = nx.DiGraph()
        
            for edge in arestas_originais:
                if len(edge) == 2:
                    u, v = edge
                    G_dir.add_edge(u, v)  # Mantém a direção das arestas
                elif len(edge) == 3:
                    u, v, weight = edge
                    G_dir.add_edge(u, v, weight=weight)  # Mantém a direção e o peso
        
            G = G_dir  # Atualiza G para o grafo orientado
            orientado = True
            elements = gerar_elementos_cytoscape(G)

        elif button_id == 'transformar_nao_orientado':
            if G.number_of_nodes() == 0:
                return elements, html.P("Nenhum grafo carregado.")
        
            if G.is_directed():
                G_n_dir = nx.Graph()
        
                for edge in arestas_originais:
                    if len(edge) == 2:
                        u, v = edge
                        G_n_dir.add_edge(u, v)  # Adiciona a aresta u-v
                    elif len(edge) == 3:
                        u, v, weight = edge
                        G_n_dir.add_edge(u, v, weight=weight)  # Adiciona a aresta u-v com peso
        
                G = G_n_dir  # Atualiza G para o grafo não orientado
                orientado = False
                elements = gerar_elementos_cytoscape(G)
            else:
                return elements, "O grafo já é não-orientado."
        
        elif button_id == 'transformar_ponderado':
            if G.number_of_nodes() == 0:
                return elements, html.P("Nenhum grafo carregado.")
        
            if ponderado:
                return elements, html.P("O grafo já é ponderado.")
        
            # Recupera os pesos das arestas armazenadas em arestas_originais
            for u, v in G.edges():
                for edge in arestas_originais:
                    if len(edge) == 3 and ((u == edge[0] and v == edge[1]) or (u == edge[1] and v == edge[0])):
                        G[u][v]['weight'] = edge[2]  # Recupera o peso original
        
            ponderado = True
            elements = gerar_elementos_cytoscape(G)
        
        elif button_id == 'transformar_nao_ponderado':
            if G.number_of_nodes() == 0:
                return elements, html.P("Nenhum grafo carregado.")
        
            if not ponderado:
                return elements, html.P("O grafo já é não ponderado.")
        
            # Remove o atributo 'weight', mas os pesos continuam armazenados em arestas_originais
            for u, v in G.edges():
                G[u][v].pop('weight', None)  # Remove o peso
        
            ponderado = False
            elements = gerar_elementos_cytoscape(G)

        elif button_id == 'Atualizar':
            if G.number_of_nodes() == 0:
                return elements, html.P("Nenhum grafo carregado.")
    
            elements = gerar_elementos_cytoscape(G)

        adjacency_list = [
            html.P(
                children=[
                    html.B(node),  # Vértice em negrito
                    " -> ",
                    ', '.join(map(str, sorted(neighbors)))  # Ordena os vizinhos em ordem crescente
                ],
                style={'margin': '0', 'padding': '0'}  # Remove margens e espaçamentos
            ) for node, neighbors in nx.to_dict_of_lists(G).items()
        ]

        info = [
            html.P(f"Número de Vértices: ", style={'display': 'inline'}),
            html.B(f"{len(G.nodes)}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Número de Arestas: ", style={'display': 'inline'}),
            html.B(f"{len(G.edges)}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Ponderado: ", style={'display': 'inline'}),
            html.B(f"{'Sim' if ponderado else 'Não'}", style={'display': 'inline'}),
            html.Br(),
            html.P(f"Orientado: ", style={'display': 'inline'}),
            html.B(f"{'Sim' if orientado else 'Não'}", style={'display': 'inline'}),
            html.Br(),
            html.Br(),
            html.P(f"Lista de Adjacência: "),
            *adjacency_list,  # Exibindo a lista de adjacência formatada
        ]
        
        return elements, info
    
    except Exception as e:
        return elements, html.P(f"Erro: {str(e)}")

@app.callback(
    Output("download-text", "data"),
    Input("salvar-grafo", "n_clicks"),
    prevent_initial_call=True,
)
def func(n_clicks):

    # Salvar o grafo em formato .txt
    conteudo = salvar_grafo_txt(G, G.is_directed())
    
    return dict(content=conteudo, filename="grafo.txt")

# Lista de layouts disponíveis
layouts = ['preset', 'circle', 'grid', 'breadthfirst', 'cose']

@app.callback(
    Output('visualizacao_grafo', 'layout'),
    [Input('layout-button', 'n_clicks')]
)
def update_layout(n_clicks):
    # Troca o layout com base no número de cliques
    layout_index = n_clicks % len(layouts)
    return {'name': layouts[layout_index], 'animate': True}


if __name__ == '__main__':
    app.run_server(debug=True, port=8052)